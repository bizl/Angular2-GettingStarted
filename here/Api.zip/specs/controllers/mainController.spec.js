﻿/// <reference path='../../Scripts/lib/jquery/jquery-1.9.1.min.js' />
/// <reference path='../../Scripts/lib/angular/angular.js' />
/// <reference path='../../Scripts/lib/kendo/kendo.all.min.js' />
/// <reference path='../../Scripts/lib/angular/angular-animate.js' />
/// <reference path='../../Scripts/lib/angular/angular-resource.js' />
/// <reference path='../../Scripts/lib/angular/ui-router.js' />
/// <reference path='../../Scripts/lib/angular/angular-mocks.js' />
/// <reference path='../../Scripts/app/app.js' />

/// <reference path='../mock-data.js' />
/// <reference path='../../Scripts/app/services/configService.js' />
/// <reference path="../../Scripts/app/services/vehicleService.js" />
/// <reference path="../../Scripts/app/services/imageService.js" />
/// <reference path='../../Scripts/app/services/imageBuilderService.js' />
/// <reference path='../../Scripts/app/services/marketModelYearService.js' />
/// <reference path='../../Scripts/app/services/directoryBuilderService.js' />
/// <reference path="../../Scripts/app/services/unMatchedDataService.js" />
/// <reference path="../../Scripts/app/services/zipDataService.js" />
/// <reference path="../../Scripts/app/services/customActionDataService.js" />
/// <reference path="../../Scripts/app/services/HelperService.js" />
/// <reference path='../../Scripts/app/controllers/mainController.js' />
/// <reference path='../bard/sinon.js' />
/// <reference path='../bard/bard.js' />
describe('main controller', function () {
    var controller, markets, vehicleService, configuration;

    function initialiseController(market, model, year, domain) {
        $state = {
            params: {
                market: market,
                model: model,
                year: year,
                domain: domain
            },
            go: sinon.spy()
        };
        
        controller = $controller('mainController', {
            $state: $state,
            vehicleService: vehicleService,
            toaster: bard.fakeToastr,
            configuration: configuration
        });
    }

    beforeEach(function () {
        bard.appModule('bobApp');
        bard.inject('$controller', '$state', '$q', '$stateParams', '$rootScope', 'configService',
                    'vehicleService', 'marketModelYearDataService', 'imageService','imageBuilderService','unmatchedDataService',
                    'directoryBuilderService', 'zipDataService', 'customActionDataService',
                    'configuration');

        markets = mockData.getMockMarkets();

        vehicleService = {
            selectedVehicle: {
                year: {
                    description: 2000
                },
                market: {
                    code: 'UK'
                },
                model: {
                    description: 'AB'
                }
            },
            imagesToBuild: [{ filePath: 'AA' }]
        }

        bard.mockService(unmatchedDataService , {
            getUnmatched: function () {
                return $q.when(["/UK/2016.50/FIESTA B299 MCA/ImagesGForce9/blazerblue.jpg","/UK/2016.50/FIESTA B299 MCA/ImagesGForce9/candyblue.jpg"]);
            }
        });

        configuration = {
            formatTypes: [
                { code: 'USC', description: 'Vista Tables', self: '/usc' },
                { code: 'WERS', description: 'Generic Feed', self: '/wers' }
            ],
            baseUrl: '//localhost/',
            baseImage: 'aa'
        };

        bard.mockService(configService, {
            getConfiguration: () => {
                return {
                    then: (callback) => {
                        callback({data: configuration});
                    }
                }
            }
        });

        bard.mockService(marketModelYearDataService, {
            gettingMarket: function () {
                return $q.when({ data: markets });
            },
            gettingSelf: function (url) {
                if (url === '/Market/AUT') {
                    return $q.when({data: mockData.getMockModel()});
                }
                return $q.when({data: mockData.getMockYear()});
            },
            gettingGroups: function () {
                return $q.when({ data: mockData.getMockGroups() });
            }
        });

        bard.mockService(imageService, {
            buildImagePath:function() {
                return "1";
            }
        });
    });

    it('should exist', function () {
        initialiseController();
        expect(controller).toBeDefined();
    });

    describe('getting data by URL', () => {
        let gettingGroupSpy;

        beforeEach(() => {
            gettingGroupSpy = sinon.spy(marketModelYearDataService, 'gettingGroups');
        });

        it('does NOT call gettingGroups when the url has no information', () => {
            initialiseController();
            expect(gettingGroupSpy.called).toBe(false);
        });

        it('does NOT call gettingGroups when the url has incomplete pararmeters', () => {
            initialiseController('market', 'model');
            expect(gettingGroupSpy.called).toBe(false);
        });

        it('does call gettingGroups when all the information is in the URL', () => {
            initialiseController('market', 'model', 'year');
            expect(gettingGroupSpy.called).toBe(true);
        });
    });

    describe('populating Dropdowns', () => {
        let gettingMarketSpy,
            marketCode = 'AUT',
            modelCode = '00K',
            yearCode = 'YYV';

        beforeEach(() => {
            gettingMarketSpy = sinon.spy(marketModelYearDataService, 'gettingMarket');            
        });

        it('should get market data', () => {
            initialiseController();
            $rootScope.$apply();
             
            expect(gettingMarketSpy.called).toBe(true);
            expect(controller.markets).toBeDefined();
        });

        describe('domain selection', () => {
            it('should select the first option if NO domain is provided', () => {
                initialiseController();
                $rootScope.$apply();

                expect(controller.selectedFormatType.code).toBe('USC');
            });

            it('should set the selected domain when the url is set', () => {
                initialiseController(null, null, null, 'WERS');
                $rootScope.$apply();

                expect(controller.selectedFormatType.code).toBe('WERS');
            });
        });

        describe('market dropdown', () => {
            it('should NOT set the selected market when the url is empty', () => {
                initialiseController();
                $rootScope.$apply();

                expect(controller.vehicle.market).not.toBeDefined();
            });

            it('should set the selected market when the url has the market property set', () => {
                initialiseController(marketCode);
                $rootScope.$apply();

                expect(controller.vehicle.market).toBeDefined();
                expect(controller.vehicle.market.code).toBe(marketCode);
                expect(controller.vehicle.market.description).toBe('Austria');
                expect(controller.models).toBeDefined();
            });

            it('should set the selected market when the url has the market property set in lowercase', () => {
                initialiseController(marketCode.toLowerCase());
                $rootScope.$apply();

                expect(controller.vehicle.market).toBeDefined();
                expect(controller.vehicle.market.code).toBe(marketCode);
                expect(controller.vehicle.market.description).toBe('Austria');
            });
        });

        describe('model dropdown', () => {
            it('should NOT set the selected model when the url ONLY has the model property set', () => {
                initialiseController(undefined, modelCode);
                $rootScope.$apply();

                expect(controller.vehicle.model).not.toBeDefined();
            });

            it('should set the selected market and Model when the url has the market and model property set', () => {
                initialiseController(marketCode, modelCode);
                $rootScope.$apply();

                expect(controller.vehicle.model).toBeDefined();
                expect(controller.vehicle.model.code).toBe(modelCode);
                expect(controller.vehicle.model.description).toBe('B460 TRANSIT');
            });

            it('should set the selected market when the url has the market property set in lowercase', () => {
                initialiseController(marketCode, modelCode.toLowerCase());
                $rootScope.$apply();

                expect(controller.vehicle.model).toBeDefined();
                expect(controller.vehicle.model.code).toBe(modelCode);
                expect(controller.vehicle.model.description).toBe('B460 TRANSIT');
            });
        });

        describe('year dropdown', () => {
            it('should NOT set the selected year when the url ONLY has the year property set', () => {
                initialiseController(undefined, undefined, yearCode);
                $rootScope.$apply();

                expect(controller.vehicle.year).not.toBeDefined();
            });

            it('should set the selected market and Model when the url has the market and model property set', () => {
                initialiseController(marketCode, modelCode, yearCode);
                $rootScope.$apply();

                expect(controller.vehicle.year).toBeDefined();
                expect(controller.vehicle.year.code).toBe(yearCode);
                expect(controller.vehicle.year.description).toBe('2014.50');
            });

            it('should set the selected market when the url has the market property set in lowercase', () => {
                initialiseController(marketCode, modelCode, yearCode.toLowerCase());
                $rootScope.$apply();

                expect(controller.vehicle.year).toBeDefined();
                expect(controller.vehicle.year.code).toBe(yearCode);
                expect(controller.vehicle.year.description).toBe('2014.50');
            });
        });
    });

    describe('after activation', function () {

        beforeEach(() => {
            initialiseController();
        });

        it('trigger causes call to treeview to show', function () {
            expect(controller.showTree ).toBe(false);
            $rootScope.$broadcast('vehicleChange');
            $rootScope.$apply();

            expect(controller.showTree).toBe(true);
        });

        it('trigger causes call to marketModelYearDataService to get data', function () {
            spyOn(marketModelYearDataService, 'gettingGroups').and.callThrough();
            $rootScope.$broadcast('vehicleChange');
            expect(marketModelYearDataService.gettingGroups).toHaveBeenCalledTimes(1);
        });

        it('should populate markets', function () {
            $rootScope.$apply();
            expect(controller.markets).not.toBeUndefined();
            expect(controller.markets.length).toBeGreaterThan(0);
            expect(controller.markets.length).toEqual(mockData.getMockMarkets().length);
        });

        describe('format type change', () => {
                it('should change selectedFormatType and reset model and year properties', () => {
                    controller.vehicle.market = 'market';
                    controller.vehicle.model = 'model';
                    controller.vehicle.year = 'year';

                    controller.changeFormatSelection(controller.formatTypes[1]);
                    $rootScope.$apply();

                    expect(controller.selectedFormatType).toEqual(controller.formatTypes[1]);
                    expect(controller.vehicle.market).not.toBeDefined();
                    expect(controller.vehicle.model).not.toBeDefined();
                    expect(controller.vehicle.year).not.toBeDefined();
                });
            });

        describe('market change', function () {
            beforeEach(() => {
                controller.vehicle.year = 1;
                controller.vehicle.market = { 'code': 'AUT', 'description': 'Austria', 'self': '/Market/AUT' };
                spyOn($rootScope, '$broadcast');
            });

            it('should clear year', function() {
                controller.changeMarket();
                $rootScope.$apply();
                expect(controller.year).toBeUndefined();
            });

            it('should populate models', function () {
                controller.changeMarket();
                $rootScope.$apply();

                var modelsLength = controller.models.length;
                expect(modelsLength).toEqual(mockData.getMockModel().length);
            });

            it('should update stateParams with the new market code', () => {
                controller.changeMarket();
                $rootScope.$apply();
                
                expect($state.go.secondCall.args[1].market).toBe('AUT');
            });

            describe('model change', function () {
                it('should populate years', function () {

                    controller.vehicle.model = { 'code': '00K', 'description': 'B460 TRANSIT', 'self': '/market/GBR/model/00K' };
                    controller.changeModel();
                    $rootScope.$apply();

                    var yearLength = controller.years.length;
                    expect(yearLength).toEqual(mockData.getMockYear().length);
                });

                it('should update stateParams wit the new model code', () => {
                    controller.vehicle.model = { 'code': '00K', 'description': 'B460 TRANSIT', 'self': '/market/GBR/model/00K' };

                    controller.changeModel();
                    $rootScope.$apply();

                    expect($state.go.secondCall.args[1].model).toBe('00K');
                });
            });

            describe('year change', function () {


                it('should broadcast year change', function () {
                    controller.vehicle.year = { code: "YYV", description: "2014.50" , self:'/'};
                    controller.vehicleHasChanged();
                    $rootScope.$apply();
                    expect($rootScope.$broadcast).toHaveBeenCalledWith('vehicleChange');
                });

                it('should update stateParams wit the new year code', () => {
                    controller.vehicle.year = { code: "YYV", description: "2014.50", self: '/' };

                    controller.vehicleHasChanged();
                    $rootScope.$apply();

                    expect($state.go.secondCall.args[1].year).toBe('YYV');
                });
            });

            describe('refresh button click', function () {
                it('triggers a refresh on the treeview', function () {
                    controller.refreshView();
                    $rootScope.$apply();
                    expect($rootScope.$broadcast).toHaveBeenCalled();
                });
            });

        });
    });

    describe('Custom Actions', () => {
        let marketCode = 'AUT',
            modelCode = '00K',
            yearCode = 'YYV';

        beforeEach((done) => {
            initialiseController(marketCode, modelCode, yearCode);
            $rootScope.$broadcast('vehicleChange');
            $rootScope.$apply();
            done();
        });

        it('should have no custom actions on tab 0', () => {
            expect(controller.tabList[0].name).toBe(controller.selectedTab.name);
            expect(controller.selectedTab.customActions.length).toBe(0);
        });

        it('should have 1 custom action on tab 1', () => {
            controller.tabClicked(controller.tabList[1]);

            expect(controller.tabList[1].name).toBe(controller.selectedTab.name);
            expect(controller.selectedTab.customActions.length).toBe(1);
        });

        it('should have 3 custom actions on tab 2', () => {
            controller.tabClicked(controller.tabList[2]);

            expect(controller.tabList[2].name).toBe(controller.selectedTab.name);
            expect(controller.selectedTab.customActions.length).toBe(3);
        });
    });

    describe('unmatched click', function () {
        beforeEach(() => {
            initialiseController();
        });

        it('should build unmatched data', function () {
            spyOn(unmatchedDataService, 'getUnmatched').and.callThrough();

            expect(controller.missingData).toBeUndefined();

            controller.missingFiles();
            $rootScope.$apply();

            expect(controller.missingData).not.toBeUndefined();
            expect(unmatchedDataService.getUnmatched).toHaveBeenCalled();
        });
    });
})