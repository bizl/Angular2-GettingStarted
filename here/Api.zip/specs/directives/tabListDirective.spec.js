﻿/// <template path="../../partials/tabList.html" mode="script" id="template_tabList" type="text/ng-template" />
/// <reference path='../../Scripts/lib/jquery/jquery-1.9.1.min.js' />
/// <reference path='../../Scripts/lib/angular/angular.js' />
/// <reference path='../../Scripts/lib/kendo/kendo.all.min.js' />
/// <reference path='../../Scripts/lib/angular/angular-animate.js' />
/// <reference path='../../Scripts/lib/angular/angular-resource.js' />
/// <reference path='../../Scripts/lib/angular/ui-router.js' />
/// <reference path='../../Scripts/lib/angular/angular-mocks.js' />
/// <reference path='../../Scripts/app/app.js' />
/// <reference path="../../Scripts/app/directives/tabListDirective.js" />
/// <reference path='../bard/sinon.js' />
/// <reference path='../bard/bard.js' />

describe('directive: tabList', function () {
    var element,
        scope,
        tabs = [{ name :'zz' }, { name: 'ee' }, { name: 'ab' }];

    function addLoadedPartialHtmlToAngularTemplateCache($templateCache) {
        var template = document.getElementById("template_tabList").innerHTML;
        $templateCache.put("partials/tabList.html", template);
    }

    beforeEach(function () {
        bard.appModule('bobApp');
    });

    beforeEach(function () {
        inject(addLoadedPartialHtmlToAngularTemplateCache);
    });

    beforeEach(inject(function ($rootScope, $compile) {
        scope = $rootScope.$new();
        element = '<tab-List tabs="List" current="\'ab\'" tab-click="tabClicked(tab)"></tab-List>';

        scope.List = tabs;
        scope.tabClicked = function() {};
        element = $compile(element)(scope);
        scope.$digest();
    }));

    describe('List is shown', function () {
        it('should change to default image', function () {
            var isolated = element.isolateScope();

            expect(isolated.tabs).toEqual(tabs);
        });

        it('defaults to the correct tab', function () {
            var isolated = element.isolateScope();

            expect(isolated.current).toEqual('ab');
        });

        it('with 3 tabs shows 3 tabs ', function () {
            expect(element.find(".ng-binding").length).toEqual(3);
        });

        it('with the tabs in the correct order', function () {
            var tabsFound = element.find("li>a");
            expect(tabsFound[0].text).toEqual(tabs[0].name);
            expect(tabsFound[1].text).toEqual(tabs[1].name);
            expect(tabsFound[2].text).toEqual(tabs[2].name);
        });

    });
});