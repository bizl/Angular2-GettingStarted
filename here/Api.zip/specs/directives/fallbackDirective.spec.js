﻿/// <reference path='../../Scripts/lib/jquery/jquery-1.9.1.min.js' />
/// <reference path='../../Scripts/lib/angular/angular.js' />
/// <reference path='../../Scripts/lib/kendo/kendo.all.min.js' />
/// <reference path='../../Scripts/lib/angular/angular-animate.js' />
/// <reference path='../../Scripts/lib/angular/angular-resource.js' />
/// <reference path='../../Scripts/lib/angular/ui-router.js' />
/// <reference path='../../Scripts/lib/angular/angular-mocks.js' />
/// <reference path='../../Scripts/app/app.js' />
/// <reference path="../../Scripts/app/directives/fallbackDirective.js" />

/// <reference path='../bard/sinon.js' />
/// <reference path='../bard/bard.js' />

xdescribe('directive: fallback-src', function () {
    var element, scope, timeout =3000;
  
    beforeEach(function () {
        bard.appModule('bobApp');
        bard.inject('configuration');

    });


    describe('src image doesn\'t exist', function () {
        beforeEach(inject(function ($rootScope, $compile) {
            scope = $rootScope.$new();
            configuration.fallBackImage = 'https://www.google.co.uk/images/nav_logo242.png';
            element = $compile('<img src="http://www.google.com/image.jpg" fallback-src/>')(scope);
            element.scope().$apply();
        }));

        it('should change to default image', function (done) {
            setTimeout(function () {
                expect(element.attr('src')).toBe(configuration.fallBackImage);
                done();
            }, timeout);
        });
    });

    describe('src image does exist', function () {
        var src = "https://www.google.co.uk/images/nav_logo242.png";

        beforeEach(inject(function ($rootScope, $compile) {

                scope = $rootScope.$new();
                configuration.fallBackImage = "http://www.google.com/image.jpg";
                element = $compile('<img src="' + src + '" fallback-src/>')(scope);
                element.scope().$apply();
        }));

        it('should not change src', function (done) {
            setTimeout(function () {
                expect(element.attr('src')).toBe(src);
                done();
            }, timeout);
        });
    });
});