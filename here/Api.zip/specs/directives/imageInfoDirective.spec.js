﻿/// <template path="../../partials/tabList.html" mode="script" id="template_tabList" type="text/ng-template" /> 
/// <reference path='../../Scripts/lib/jquery/jquery-1.9.1.min.js' />
/// <reference path='../../Scripts/lib/angular/angular.js' />
/// <reference path='../../Scripts/lib/kendo/kendo.all.min.js' />
/// <reference path='../../Scripts/lib/angular/angular-animate.js' />
/// <reference path='../../Scripts/lib/angular/angular-resource.js' />
/// <reference path='../../Scripts/lib/angular/ui-router.js' />
/// <reference path='../../Scripts/lib/angular/angular-mocks.js' />
/// <reference path='../../Scripts/app/app.js' />
/// <reference path="../../Scripts/app/directives/imageInfoDirective.js" />
/// <reference path="../../Scripts/app/services/imageInfoService.js" />
/// <reference path='../bard/sinon.js' />
/// <reference path='../bard/bard.js' />

describe('directive: imageInfo', function () {
    var element,
        scope;
    
    beforeEach(function () {
        bard.appModule('bobApp');
        bard.inject('$q', '$rootScope');
        
    });

    beforeEach(inject(function ($rootScope, $compile) {
        scope = $rootScope.$new();
        element = '<image-info file-size="210000" width="100" height="200"></image-info>';
  
        element = $compile(element)(scope);
        scope.$digest();
    }));

    describe('List is shown', function () {
        it('should change to default image', function () {
            var isolated = element.isolateScope();
          
            expect(isolated.width).toEqual(100);
            expect(isolated.height).toEqual(200);
            expect(isolated.fileSize).toEqual(210000);
        });
    });
});