﻿var mockData = (function () {
    return {
        getMockMarkets: getMockMarkets,
        getMockModel: getMockModel,
        getMockYear: getMockYear,
        getMockGroups: getMockGroups
    }

    function getMockMarkets() {
        return [{ 'code': 'AUT', 'description': 'Austria', 'self': '/Market/AUT' }, { 'code': 'BEL', 'description': 'BelgiumFR', 'self': '/Market/BEL' }, { 'code': 'CZE', 'description': 'CzechRepublicEN', 'self': '/Market/CZE' }, { 'code': 'DNK', 'description': 'Denmark', 'self': '/Market/DNK' }, { 'code': 'FIN', 'description': 'Finland', 'self': '/Market/FIN' }, { 'code': 'FRA', 'description': 'France', 'self': '/Market/FRA' }, { 'code': 'DEU', 'description': 'Germany', 'self': '/Market/DEU' }, { 'code': 'GRC', 'description': 'Greece', 'self': '/Market/GRC' }, { 'code': 'HUN', 'description': 'Hungary', 'self': '/Market/HUN' }, { 'code': 'IRL', 'description': 'Ireland', 'self': '/Market/IRL' }, { 'code': 'ITA', 'description': 'Italy', 'self': '/Market/ITA' }, { 'code': 'NLD', 'description': 'Netherlands', 'self': '/Market/NLD' }, { 'code': 'NOR', 'description': 'Norway', 'self': '/Market/NOR' }, { 'code': 'POL', 'description': 'Poland', 'self': '/Market/POL' }, { 'code': 'PRT', 'description': 'Portugal', 'self': '/Market/PRT' }, { 'code': 'ROU', 'description': 'Romania', 'self': '/Market/ROU' }, { 'code': 'RUS', 'description': 'Russia', 'self': '/Market/RUS' }, { 'code': 'ESP', 'description': 'Spain', 'self': '/Market/ESP' }, { 'code': 'SWE', 'description': 'Sweden', 'self': '/Market/SWE' }, { 'code': 'CHE', 'description': 'SwitzerlandDE', 'self': '/Market/CHE' }, { 'code': 'TUR', 'description': 'Turkey', 'self': '/Market/TUR' }, { 'code': 'GBR', 'description': 'UK', 'self': '/Market/GBR' }];
    }

    function getMockModel() {
        return [{ 'code': '00K', 'description': 'B460 TRANSIT', 'self': '/market/GBR/model/00K' }, { 'code': '008', 'description': 'B515 ECOSPORT', 'self': '/market/GBR/model/008' }, { 'code': '004', 'description': 'BMAX B232', 'self': '/market/GBR/model/004' }, { 'code': '00O', 'description': 'C520 KUGA', 'self': '/market/GBR/model/00O' }, { 'code': '009', 'description': 'CMAX C344', 'self': '/market/GBR/model/009' }, { 'code': '00P', 'description': 'CMAX C344 MCA', 'self': '/market/GBR/model/00P' }, { 'code': '00E', 'description': 'EDGE (CD539X)', 'self': '/market/GBR/model/00E' }, { 'code': '00C', 'description': 'FIESTA B299 MCA', 'self': '/market/GBR/model/00C' }, { 'code': '00I', 'description': 'FOCUS C346', 'self': '/market/GBR/model/00I' }, { 'code': '00L', 'description': 'FOCUS C346 MCA', 'self': '/market/GBR/model/00L' }, { 'code': '00F', 'description': 'GALAXY (CD340 LMV)', 'self': '/market/GBR/model/00F' }, { 'code': '002', 'description': 'GALAXY CD390 LMV', 'self': '/market/GBR/model/002' }, { 'code': '00G', 'description': 'KA (B420)', 'self': '/market/GBR/model/00G' }, { 'code': '00Q', 'description': 'MONDEO (CD345)', 'self': '/market/GBR/model/00Q' }, { 'code': '00R', 'description': 'MONDEO CD391 EU', 'self': '/market/GBR/model/00R' }, { 'code': '00S', 'description': 'MUSTANG', 'self': '/market/GBR/model/00S' }, { 'code': '00U', 'description': 'RANGER P375', 'self': '/market/GBR/model/00U' }, { 'code': '006', 'description': 'SMAX (CD340 SAV)', 'self': '/market/GBR/model/006' }, { 'code': '00A', 'description': 'SMAX (CD539)', 'self': '/market/GBR/model/00A' }, { 'code': '005', 'description': 'V408', 'self': '/market/GBR/model/005' }];
    }

    function getMockYear() {
        return [{ 'code': 'YYV', 'description': '2014.50' }, { 'code': 'YYA', 'description': '2015.75' }, { 'code': 'YYB', 'description': '2016' }];
    }

    function getMockCustomActionOk() {
        return {
            status : 'Ok',
            message : 'asdasd'
        } 
    }

    function getMockGroups() {
        return {
            "imageTypeSet":
            [
                {
                    "name": "Exterior",
                    "contentPath": "imagesgforce9",
                    "customActions": [],
                    "imageGroups": [
                        {
                            "name": "FROZEN WHITE",
                            "groups": [
                                {
                                    "name": "SPORT UTILITY",
                                    "groups": [
                                        {
                                            "name": "ZETEC",
                                            "groups": [],
                                            "images": [
                                                {
                                                    "fileName": "gbr00oyyd7SA7TI(a)(a)7X5_1_0.png"
                                                },
                                                {
                                                    "fileName": "gbr00oyyd7SA7TI(a)(a)7X5_2_0.png"
                                                },
                                                {
                                                    "fileName": "gbr00oyyd7SA7TI(a)(a)7X5_3_0.png"
                                                },
                                                {
                                                    "fileName": "gbr00oyyd7SA7TI(a)(a)7X5_4_0.png"
                                                },
                                                {
                                                    "fileName": "gbr00oyyd7SA7TI(a)(a)7X5_5_0.png"
                                                },
                                                {
                                                    "fileName": "gbr00oyyd7SA7TI(a)(a)7X5_6_0.png"
                                                },
                                                {
                                                    "fileName": "gbr00oyyd7SA7TI(a)(a)7X5_7_0.png"
                                                },
                                                {
                                                    "fileName": "gbr00oyyd7SA7TI(a)(a)7X5_8_0.png"
                                                },
                                                {
                                                    "fileName": "gbr00oyyd7SA7TI(a)(a)7X5_9_0.png"
                                                }]
                                        }]
                                }]
                        }]
                },
                {
                    "name": "singleTab",
                    "customActions": [
                        {
                            "name": "action1",
                            "endpoint": "api/action1"
                        }
                    ],
                    "imageGroups": []
                },
                {
                    "name": "multipleTabs",
                    "customActions": [
                        {
                            "name": "action1",
                            "endpoint": "api/action1"
                        },
                        {
                            "name": "action2",
                            "endpoint": "api/action2"
                        },
                        {
                            "name": "action3",
                            "endpoint": "api/action3"
                        }
                    ],
                    "imageGroups": []
                }]
        }
    }
})();