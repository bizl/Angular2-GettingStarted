﻿/// <reference path='../../Scripts/lib/jquery/jquery-1.9.1.min.js' />
/// <reference path='//kendo.cdn.telerik.com/2016.1.112/js/jquery.min.js'/>
/// <reference path='../../Scripts/lib/angular/angular.js' />
/// <reference path='../../Scripts/lib/kendo/kendo.all.min.js' />
/// <reference path='../../Scripts/lib/angular/angular-animate.js' />
/// <reference path='../../Scripts/lib/angular/angular-resource.js' />
/// <reference path='../../Scripts/lib/angular/ui-router.js' />
/// <reference path='../../Scripts/lib/angular/angular-mocks.js' />
/// <reference path='../../Scripts/app/app.js' />
/// <reference path='../mock-data.js' />
/// <reference path='../bard/sinon.js' />
/// <reference path='../bard/bard.js' />
/// <reference path='../../Scripts/app/services/zipDataService.js' />
/// <reference path='../../Scripts/app/services/HelperService.js' />
describe('zip data service', function () {
    var baseZipUrl = 'api/build';

    beforeEach(function () {
        bard.appModule('bobApp');
        bard.inject('zipDataService', '$httpBackend','helperService');
    });

     afterEach(function () {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
     });

    it('build a zip should return a 200', function () {
        var expectedUrl = baseZipUrl ;

        $httpBackend.expect('POST', expectedUrl)
          .respond(200);
        var imageList = [{ filePath: '1.jpg', targetFolder: 'c:' }, { filePath: '2.jpg', targetFolder: 'c:' }];

        zipDataService
                .buildZip(imageList, 'A','B','C')
                .then(function (result) {
                	expect(result.status).toEqual(200);
                });

        $httpBackend.flush();
    });
})