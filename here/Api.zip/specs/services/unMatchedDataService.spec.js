﻿/// <reference path='../../Scripts/lib/jquery/jquery-1.9.1.min.js' />
/// <reference path='//kendo.cdn.telerik.com/2016.1.112/js/jquery.min.js'/>
/// <reference path='../../Scripts/lib/angular/angular.js' />
/// <reference path='../../Scripts/lib/kendo/kendo.all.min.js' />
/// <reference path='../../Scripts/lib/angular/angular-animate.js' />
/// <reference path='../../Scripts/lib/angular/angular-resource.js' />
/// <reference path='../../Scripts/lib/angular/ui-router.js' />
/// <reference path='../../Scripts/lib/angular/angular-mocks.js' />
/// <reference path='../../Scripts/app/app.js' />
/// <reference path='../bard/sinon.js' />
/// <reference path='../bard/bard.js' />
/// <reference path='../../Scripts/app/services/unmatchedDataService.js' />


describe("custom action data service", function () {

    var selectedVehicle = {
        market: { code: "GBR" },
        model: { code: "0OL" },
        year: { code: "YY0" }
    };

    beforeEach(function () {
        bard.appModule("bobApp");
        bard.inject("unmatchedDataService", "$httpBackend", "configuration");
    });

    afterEach(function () {

        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    });

    it("getUnmatched should return ok", function () {
        var expectedUrl = configuration.baseUnMatchedUrl;

        var expected = {
            files: ["Ab", "BB"],
            market: selectedVehicle.market.code,
            model: selectedVehicle.model.code,
            year: selectedVehicle.year.code,
            formatType: "wers"
        };

        $httpBackend.expectPOST(expectedUrl, expected)
          .respond(200);

        unmatchedDataService
            .getUnmatched(["Ab", "BB"], selectedVehicle.market, selectedVehicle.model, selectedVehicle.year, "wers");

        expect($httpBackend.flush).not.toThrow();
    });


});