﻿/// <reference path='../../Scripts/lib/jquery/jquery-1.9.1.min.js' />
/// <reference path='//kendo.cdn.telerik.com/2016.1.112/js/jquery.min.js'/>
/// <reference path='../../Scripts/lib/angular/angular.js' />
/// <reference path='../../Scripts/lib/kendo/kendo.all.min.js' />
/// <reference path='../../Scripts/lib/angular/angular-animate.js' />
/// <reference path='../../Scripts/lib/angular/angular-resource.js' />
/// <reference path='../../Scripts/lib/angular/ui-router.js' />
/// <reference path='../../Scripts/lib/angular/angular-mocks.js' />
/// <reference path='../../Scripts/app/app.js' />
/// <reference path='../mock-data.js' />
/// <reference path='../bard/sinon.js' />
/// <reference path='../bard/bard.js' />
/// <reference path='../../Scripts/app/services/directoryBuilderService.js' />


describe('create a directory object', function () {

    beforeEach(function () {
        bard.appModule('bobApp');

        bard.inject('directoryBuilderService');

    });


    var filePath = "content/Austria/2014.50/1.png",
        filePath2 = "content/Austria/2015/2.png",
        filePath3 = "content/Austria/2015/3.png";

    var expected = '1.png',
        expected2 = '2.png',
        expected3 = '3.png';

    it('a single item string returns an item one deep', function () {

        var files= [];
        files.push('1.png');
        var result = directoryBuilderService.build (files);

        expect(result.items[0].name).toEqual(expected);
    });

    it('a multi directory returns correct depth path and file name', function () {
        
        var files = { filePath, filePath2, filePath3 };
        var result = directoryBuilderService.build(files);

        expect(result.items[0].items[0].items[0].items[0].name).toEqual(expected);
    });

    it('add multiple directories multi directory returns correct depth path and file name', function () {

        var files = {filePath, filePath2};
        var result = directoryBuilderService.build(files);
        
        expect(result.items[0].items[0].items[0].items[0].name).toEqual(expected);
        expect(result.items[0].items[0].items[1].items[0].name).toEqual(expected2);
    });

    it('add multiple directories multi files returns correct depth path and file name', function () {
      
        var files = { filePath, filePath2, filePath3 };
        var result = directoryBuilderService.build(files);

        expect(result.items[0].items[0].items[0].items[0].name).toEqual(expected);
        expect(result.items[0].items[0].items[1].items[0].name).toEqual(expected2);
        expect(result.items[0].items[0].items[1].items[1].name).toEqual(expected3);
    });

})