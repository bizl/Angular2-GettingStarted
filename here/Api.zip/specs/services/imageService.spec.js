﻿/// <reference path='../../Scripts/lib/jquery/jquery-1.9.1.min.js' />
/// <reference path='//kendo.cdn.telerik.com/2016.1.112/js/jquery.min.js'/>
/// <reference path='../../Scripts/lib/angular/angular.js' />
/// <reference path='../../Scripts/lib/kendo/kendo.all.min.js' />
/// <reference path='../../Scripts/lib/angular/angular-animate.js' />
/// <reference path='../../Scripts/lib/angular/angular-resource.js' />
/// <reference path='../../Scripts/lib/angular/ui-router.js' />
/// <reference path='../../Scripts/lib/angular/angular-mocks.js' />
/// <reference path='../../Scripts/app/app.js' />
/// <reference path='../mock-data.js' />
/// <reference path='../bard/sinon.js' />
/// <reference path='../bard/bard.js' />
/// <reference path='../../Scripts/app/services/imageService.js' />
/// <reference path='../../Scripts/app/services/helperService.js' />
describe('image service', function () {
    beforeEach(function () {
        bard.appModule('bobApp');

        var vehicleService = {
            selectedVehicle: {
                year: {
                    description: '2016.50'
                },
                market: {
                    description: 'UK'
                },
                model: {
                    description: 'FIESTA B299 MCA'
                }
            }
        }

        module(function ($provide) {
            $provide.value('vehicleService', vehicleService);
        });

        bard.inject('imageService', '$q', '$rootScope', 'helperService', 'configuration');

        configuration.baseImageUrl = 'content';
    });

    it('should build image path correctly', function () {
        var result = imageService.buildImagePath({ fileName: 'abc.jpg' }, "ImagesGForce9");
        expect(result).toContain('content/ImagesGForce9/abc.jpg');
    });

    it('should build encode url image path correctly', function () {
        var result = imageService.buildImagePath({ fileName: 'abc!"£!"£.jpg' }, "ImagesGForce9");
        expect(result).toContain('content/ImagesGForce9/abc!%22%C2%A3!%22%C2%A3.jpg');
    });

    it('should not double encode url image path', function () {
        var result = imageService.buildImagePath({ fileName: 'gbrttg01bodystyleCA#XA.jpg' }, "ImagesGForce9");
        expect(result).toContain('content/ImagesGForce9/gbrttg01bodystyleCA%23XA.jpg');
    });

    it('createUnCachedImageFileName should not encode url image path', function () {
        var result = imageService.createUnCachedImageFileName('gbrttg01bodystyleCA#XA.jpg');
        expect(result).toContain('gbrttg01bodystyleCA#XA.jpg');
    });
});