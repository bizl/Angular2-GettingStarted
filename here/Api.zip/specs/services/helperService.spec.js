﻿/// <reference path='../../Scripts/lib/jquery/jquery-1.9.1.min.js' />
/// <reference path='//kendo.cdn.telerik.com/2016.1.112/js/jquery.min.js'/>
/// <reference path='../../Scripts/lib/angular/angular.js' />
/// <reference path='../../Scripts/lib/kendo/kendo.all.min.js' />
/// <reference path='../../Scripts/lib/angular/angular-animate.js' />
/// <reference path='../../Scripts/lib/angular/angular-resource.js' />
/// <reference path='../../Scripts/lib/angular/ui-router.js' />
/// <reference path='../../Scripts/lib/angular/angular-mocks.js' />
/// <reference path='../../Scripts/app/app.js' />
/// <reference path='../mock-data.js' />
/// <reference path='../bard/sinon.js' />
/// <reference path='../bard/bard.js' />
/// <reference path='../../Scripts/app/services/helperService.js' />
describe("create a helper object",
    function() {

        beforeEach(function() {
            bard.appModule("bobApp");

            bard.inject("helperService");

        });

        it("an array with a single property is urldecoded correctly",
            function() {

                var files = [{ name: "TE%24T" }, { name: "H%C2%A3ll%40" }];
                var expected = [{ name: "TE$T" }, { name: "H£ll@" }];

                var result = helperService.urlDecodeArray(files, "name");

                expect(result).toEqual(expected);
            });

        it("an array with multi properties is urldecoded correctly",
            function() {

                var files = [{ name: "TE%24T", file: "TE%24T" }, { name: "H%C2%A3ll%40", file: "H%C2%A3ll%40" }];
                var expected = [{ name: "TE$T", file: "TE$T" }, { name: "H£ll@", file: "H£ll@" }];

                var result = helperService.urlDecodeArray(files, ["name", "file"]);

                expect(result).toEqual(expected);
            });

        it("a url has multiple forward slashes and is concatenated correctly",
            function() {
                var subParts = ["/1/", "2", "/3", "4/"];

               var r = helperService.concatUrl("/AA/", subParts);

                expect(r).toEqual("/AA/1/2/3/4");
            });

        it("a url has multiple back slashes and is concatenated correctly",
           function () {
               var subParts = ["\\1\\", "2", "\\3", "4\\"];

               var r = helperService.concatUrl("/AA\\", subParts);

               expect(r).toEqual("/AA/1/2/3/4");
           });

        it("a url has multiple different slashes and is concatenated correctly",
            function () {
                var subParts = ["\\1\\", "/2/3", "\\3/", "4\\"];

                var r = helperService.concatUrl("/AA/", subParts);

                expect(r).toEqual("/AA/1/2/3/3/4");
            });
    });