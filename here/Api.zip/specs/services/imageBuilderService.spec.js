﻿/// <reference path='../../Scripts/lib/jquery/jquery-1.9.1.min.js' />
/// <reference path='//kendo.cdn.telerik.com/2016.1.112/js/jquery.min.js' />
/// <reference path='../../Scripts/lib/angular/angular.js' />
/// <reference path='../../Scripts/lib/kendo/kendo.all.min.js' />
/// <reference path='../../Scripts/lib/angular/angular-animate.js' />
/// <reference path='../../Scripts/lib/angular/angular-resource.js' />
/// <reference path='../../Scripts/lib/angular/ui-router.js' />
/// <reference path='../../Scripts/lib/angular/angular-mocks.js' />
/// <reference path='../../Scripts/app/app.js' />
/// <reference path='../mock-data.js' />
/// <reference path='../bard/sinon.js' />
/// <reference path='../bard/bard.js' />
/// <reference path="../../Scripts/app/services/helperService.js" />
/// <reference path='../../Scripts/app/services/vehicleService.js' />
/// <reference path='../../Scripts/app/services/imageBuilderService.js' />
/// <reference path='../../Scripts/app/services/imageService.js' />
describe("image builder service",
    function() {
        beforeEach(function() {
            bard.appModule("bobApp");

            var vehicleService = {
                selectedVehicle: {
                    year: {
                        description: "2016.50"
                    },
                    market: {
                        description: "UK"
                    },
                    model: {
                        description: "FIESTA B299 MCA"
                    }
                }
            };
            module(function($provide) {
                $provide.value("vehicleService", vehicleService);
            });

            bard.inject("imageBuilderService", "imageService", "$q", "$rootScope","helperService");

            bard.mockService(imageService,
            {
                doesImageExist: function(item) {
                    var deferred = $q.defer();
                    item.exists = true;
                    deferred.resolve(false);
                },
                buildImagePath: function(image, anglePath) {
                    return image + anglePath;
                }
            });
        });

        var imageData = {
            "imageTypeSet": [
                {
                    "name": "aa",
                    "contentPath": "imagesgforce9",
                    "imageGroups": [
                        {
                            "name": "R83",
                            "groups": [
                                {
                                    "name": "8W1",
                                    "groups": [
                                        {
                                            "name": "9NA",
                                            "groups": [],
                                            "images": [
                                                {
                                                    "filename": "GBR00CYYBR838W1(a)(a)9NA_1_0.png",
                                                    "exists": true,
                                                    "isValid": true
                                                },
                                                {
                                                    "filename": "GBR00CYYBR838W1(a)(a)9NA_2_0.png",
                                                    "exists": true,
                                                    "isValid": true
                                                },
                                                {
                                                    "filename": "GBR00CYYBR838W1(a)(a)9NA_3_0.png",
                                                    "exists": true,
                                                    "isValid": true
                                                },
                                                {
                                                    "filename": "GBR00CYYBR838W1(a)(a)9NA_4_0.png",
                                                    "exists": true,
                                                    "isValid": true
                                                },
                                                {
                                                    "filename": "GBR00CYYBR838W1(a)(a)9NA_5_0.png",
                                                    "exists": true,
                                                    "isValid": true
                                                },
                                                {
                                                    "filename": "GBR00CYYBR838W1(a)(a)9NA_6_0.png",
                                                    "exists": true,
                                                    "isValid": true
                                                },
                                                {
                                                    "filename": "GBR00CYYBR838W1(a)(a)9NA_7_0.png",
                                                    "exists": true,
                                                    "isValid": true
                                                },
                                                {
                                                    "filename": "GBR00CYYBR838W1(a)(a)9NA_8_0.png",
                                                    "exists": true,
                                                    "isValid": true
                                                },
                                                {
                                                    "filename": "GBR00CYYBR838W1(a)(a)9NA_9_0.png",
                                                    "exists": true,
                                                    "isValid": true
                                                }
                                            ]
                                        }, {
                                            "name": "test",
                                            "groups": [],
                                            "images": [
                                                {
                                                    "filename": "GBR00CYYBR838W1(a)(a)9NA_1_0.png",
                                                    "exists": true,
                                                    "isValid": true
                                                }, {
                                                    "filename": "GBR00CYYBR838W1(a)(a)9NA_2_0.png",
                                                    "exists": true,
                                                    "isValid": true
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }, {
                    "name": "bb",
                    "contentPath": "imagesgforce9",
                    "imageGroups": [
                        {
                            "name": "aa",
                            "groups": [
                                {
                                    "name": "8W1",
                                    "images": [
                                        {
                                            "filename": "aa8w1_1_0.png",
                                            "exists": true,
                                            "isValid": true
                                        }
                                    ],
                                    "groups": [
                                        {
                                            "name": "9NA",
                                            "groups": [],
                                            "images": [
                                                {
                                                    "filename": "aa8w1_9NA_1_0.png",
                                                    "exists": true,
                                                    "isValid": false
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            ]
        };

        it("build returns valid structure",
            function() {
                var result = imageBuilderService.build(imageData);

                expect(result.selectedTab.name).toEqual("aa");
                expect(result.tabList.length).toEqual(2);

                expect(result.nodeItems[0].nodes[0].nodes[0].name).toEqual("8W1");
                expect(result.nodeItems[0].nodes[0].nodes[0].nodes[0].parentPath).toEqual("aa/R83/8W1");
            });

        it("buildImageInfo returns valid image counts",
            function() {
                var results = imageBuilderService.build(imageData);

                imageBuilderService.buildImageInfo(results.nodeItems);

                expect(results.nodeItems[0].nodes[0].nodes[0].nodes[0].count).toEqual(9);
                expect(results.nodeItems[0].nodes[0].nodes[0].nodes[0].foundCount).toEqual(9);
                expect(results.nodeItems[0].nodes[0].count).toEqual(11);
                expect(results.nodeItems[0].nodes[0].foundCount).toEqual(11);
                expect(results.nodeItems[1].foundCount).toEqual(2);
                expect(results.nodeItems[1].count).toEqual(2);
            });


        it("buildImageInfo returns isValid on the correct nodes/leafs",
            function() {

                var results = imageBuilderService.build(imageData);

                imageBuilderService.buildImageInfo(results.nodeItems);

                expect(results.nodeItems[0].nodes[0].nodes[0].isValid).toEqual(true);

                expect(results.nodeItems[0].nodes[0].isValid).toEqual(true);

                expect(results.nodeItems[0].isValid).toEqual(true);

                expect(results.nodeItems[1].isValid).toEqual(false);
            });

    })