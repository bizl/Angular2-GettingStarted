﻿/// <reference path='../../Scripts/lib/jquery/jquery-1.9.1.min.js' />
/// <reference path='//kendo.cdn.telerik.com/2016.1.112/js/jquery.min.js'/>
/// <reference path='../../Scripts/lib/angular/angular.js' />
/// <reference path='../../Scripts/lib/kendo/kendo.all.min.js' />
/// <reference path='../../Scripts/lib/angular/angular-animate.js' />
/// <reference path='../../Scripts/lib/angular/angular-resource.js' />
/// <reference path='../../Scripts/lib/angular/ui-router.js' />
/// <reference path='../../Scripts/lib/angular/angular-mocks.js' />
/// <reference path='../../Scripts/app/app.js' />
/// <reference path='../mock-data.js' />
/// <reference path='../bard/sinon.js' />
/// <reference path='../bard/bard.js' />
/// <reference path='../../Scripts/app/services/MarketModelYearService.js' />

describe('model market year data service', function () {
    var baseUrl = "";

    beforeEach(function () {
        bard.appModule('bobApp');
        bard.inject('marketModelYearDataService', '$httpBackend', 'configuration');
        baseUrl = configuration.baseApiUrl;
    });

     afterEach(function () {

        $httpBackend.flush();
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
     });

    it('should return a list of markets', function () {
        var expectedUrl = baseUrl + '/market';

        $httpBackend.expect('GET', expectedUrl)
          .respond(200, mockData.getMockMarkets);

        marketModelYearDataService
                .gettingMarket()
                .then(function (result) {
                    expect(result.data).toEqual(mockData.getMockMarkets);
                });
    });

    it('should return a list of models for the UK market', function () {
        var expectedUrl = baseUrl + '/market/GBR';

        $httpBackend.expect('GET', expectedUrl)
          .respond(200, mockData.getMockModel);

        marketModelYearDataService
                .gettingSelf('/market/GBR')
                .then(function (result) {
                    expect(result.data).toEqual(mockData.getMockModel);
                });
    });

    it('should return a list of years for Transit in the UK market', function () {
        var expectedUrl = baseUrl + '/market/GBR/model/00K';

        $httpBackend.expect('GET', expectedUrl)
          .respond(200, mockData.getMockYear);

        marketModelYearDataService
                .gettingSelf('/market/GBR/model/00K')
                .then(function (result) {
                    expect(result.data).toEqual(mockData.getMockYear);
                })
    });

    it('should return a list of the recursive groups', function () {
        var expectedUrl = 'api/images/market/GBR/model/00K/year/2014/formatType/wers';

        $httpBackend.expect('GET', expectedUrl)
          .respond(200, mockData.getMockGroups);

        marketModelYearDataService
                .gettingGroups('GBR','00K',2014,'/wers')
                .then(function (result) {
                    expect(result.data).toEqual(mockData.getMockGroups);
                });

    });
})