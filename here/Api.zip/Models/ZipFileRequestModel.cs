﻿using System.Collections.Generic;
using Bob.Domain.Models;

namespace Bob.UI.Models
{
    public class ZipFileRequestModel
    {
        public string Market { get; set; }
        public string Model { get; set; }
        public string Year { get; set; }
        public string FormatType { get; set; }
        public IEnumerable<FileDetailsModel> Files { get; set; }
    }
}
