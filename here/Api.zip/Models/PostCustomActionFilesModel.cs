﻿using System.Collections.Generic;

namespace Bob.UI.Models
{
    public class PostCustomActionFilesModel
    {
        public IEnumerable<string> FileNames { get; set; }
        public string ContentPath { get; set; }
        public string CustomAction { get; set; }
        public string FormatType { get; set; }
        public string Market { get; set; }
        public string Model { get; set; }
        public string Year { get; set; }
    }
}