﻿using System.Collections.Generic;

namespace Bob.UI.Models
{
    public class UnMatchedRequestModel
    {
        public string FormatType { get; set; }
        public string Market { get; set; }
        public string Model { get; set; }
        public string Year { get; set; }
        public IEnumerable<string> Files { get; set; }
    }
}
