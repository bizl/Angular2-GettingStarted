namespace Bob.UI.Models
{
    public class ImageInfoModel
    {
        public int Width { get; set; }

        public int Height { get; set; }

        public long FileSize { get; set; }
    }
}
