﻿namespace Bob.UI.Models
{
    public class PostCustomModel
    {
        public string ContentPath { get; set; }
        public string CustomAction { get; set; }
        public string FormatType { get; set; }
        public string Market { get; set; }
        public string Model { get; set; }
        public string Year { get; set; }
        public string ImageType { get; set; }
    }
}