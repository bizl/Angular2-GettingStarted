﻿using System.Collections.Generic;
using Bob.Domain.Models;

namespace Bob.UI.Models
{
    public class ConfigurationModel
    {
        public IEnumerable<ConfigurationFormatType> FormatTypes{ get; set; }
        public string BaseUrl { get; set; }
    }
}