﻿(function () {
    angular.module('bobApp')
    .directive('fallbackSrc', fallbackSrc);
    
    fallbackSrc.$inject = ['configuration'];
    
    function fallbackSrc(configuration) {
        return {
            link: function postLink(scope, iElement) {
                iElement.bind('error', function () {
                    if (angular.element(this).attr('errorCount')===undefined) {
                        angular.element(this).attr('errorCount', 1);
                        angular.element(this).attr('src', configuration.fallBackImage);
                    }             
                });
            }
        };   
    };
})();
