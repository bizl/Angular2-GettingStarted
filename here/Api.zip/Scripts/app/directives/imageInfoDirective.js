﻿(function () {
    angular.module('bobApp')
    .directive('imageInfo', imageInfo);



    function imageInfo() {
        return {
            restrict: 'E',
            template: 'Image details : Width:{{width}}px Height:{{height}}px  - File size:{{fileSize | number:0}} KB',
            scope: {
                width: '=',
                height: '=',
                fileSize: '='
            }
        };
    };
})();