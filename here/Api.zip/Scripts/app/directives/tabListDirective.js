﻿(function () {
    angular.module('bobApp')
    .directive('tabList', tabList);
    
    function tabList($window) {
        return {
            restrict: 'E',
            templateUrl : 'partials/tabList.html',
            scope: {
                tabs: '=',
                current: '=',
                actionClick : '&',
                tabClick: '&'
            },
            link: function (scope) {
                var tabWidth = 120;

                scope.scrollStyle = {};
                scope.scrollContainerStyle = {};

                scope.$watch('tabs', function (tabs) {
                    if (tabs !== undefined) {
                        scope.scrollStyle = { 'width': tabs.length * tabWidth + 'px' };
                    }

                    if (tabs !== undefined && tabs.length * tabWidth > $window.innerWidth) {
                        scope.scrollContainerStyle = { 'overflow-x': 'scroll' };
                    } else {
                        scope.scrollContainerStyle = { 'overflow-x': 'hidden' };
                    }
                });

                scope.itemClick = function (value) {
                    scope.current = value;
                    scope.tabClick({tab: value});       
                }
            }
        };
    };
})();
