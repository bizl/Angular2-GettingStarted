﻿(function () {
    'use strict';

    angular.module('bobApp', [
        'ngAnimate',
        'ngResource',
        'ui.router',
        'kendo.directives'
    ]).config(function ($stateProvider, $urlRouterProvider) {
        $stateProvider
           .state('imageView1', {
               abstract: true,
               templateUrl: 'partials/imageViewer.html',
               controller: 'mainController',
               controllerAs: 'vm'
           })
           .state('imageView2', {
               parent: 'imageView1',
               url: '/:domain/:market/:model/:year/',
               templateUrl: 'partials/imageViewer2.html',
               controller: 'imageViewController',
               controllerAs: 'vm',
               params: { imageSrc: null, imageType: '' }
           })
            .state('viewUnMatched', {
                url: '/viewUnMatched/:filePath',
                templateUrl: 'partials/unMatchedFileViewer.html',
                controller: 'unMatchedFileController',
                controllerAs: 'vm'
            });

        $urlRouterProvider.otherwise('/////');
    })
        .constant('configuration', {
            configurationUrl: 'api/configuration',
            baseGroupImagesUrl: 'api/images',
            baseZipUrl: 'api/build',
            baseUnMatchedUrl: 'api/unmatched',
            baseImageInfo: 'api/imageInfo',
            baseImage: 'content',
            marketUrl: '/market',
            customActionUrl: 'api/customAction',
            customFilesUrl: 'api/customFiles',
            fallBackImage: 'images/notfound.png',
            headers: {
                'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS'
            }
        })
        .constant('toastr', window.toastr);
})();