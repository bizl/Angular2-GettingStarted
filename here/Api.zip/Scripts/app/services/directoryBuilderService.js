﻿(function () {
    "use strict";

    angular.module("bobApp")
           .service("directoryBuilderService", directoryBuilderService);

    directoryBuilderService.$inject = ['configuration'];

    function directoryBuilderService(configuration) {
        var currentPath;

        this.build = function (filePaths) {
            var node = {};

            angular.forEach(filePaths, function (value) {
                currentPath = configuration.baseImageUrl + value;
                node = buildNodes(node, value);
            });
            return node;
        }

        function createItemsIfNeeded(node) {
            if (node.items === undefined) {
                node.items = [];
            }
        }

        function isFilePart(splitResult) {
            return splitResult.length === 1;
        }

        function directoryExist(node, nameToCheck) {
            for (var i = 0; i < node.items.length; i++) {
                if (node.items[i].name === nameToCheck && node.items[i].type === "directory") {
                    return {
                        notFound: false,
                        directory: node.items[i]
                    }
                }
            }

            return {
                notFound: true
            }
        }

        function removeSlashIfFirst(filePath) {
            if (filePath.length > 0 && filePath.charAt(0) === '/') {
                return filePath.substr(1);
            }
            return filePath;
        }

        function buildNodes(node, filePath) {
            var directory,
                splitResult = removeSlashIfFirst(filePath).split('/');

            createItemsIfNeeded(node);

            if (isFilePart(splitResult)) {
                node.items.push({ name: filePath, type: "file", fullPath: currentPath, hasChildren: false });
                return node;
            }

            var firstPartOfFile = splitResult[0];
            var exist = directoryExist(node, firstPartOfFile);

            if (exist.notFound) {
                node.items.push({ name: firstPartOfFile, type: "directory", hasChildren: splitResult.length > 1 });
                directory = node.items[node.items.length - 1];
            } else {
                directory = exist.directory;
            }

            var rest = splitResult.splice(1).join("/");

            buildNodes(directory, rest);

            return node;
        }
    }
})();