﻿(function () {
    "use strict";

    angular.module("bobApp")
           .service("imageBuilderService", imageBuilderService);

    imageBuilderService.$inject = ['imageService'];

    function imageBuilderService(imageService) {
        var imagesToBuild;

        function hasNodes(item) {
            return item.nodes !== undefined && item.nodes.length > 0;
        }

        function hasExistsProperty(item) {
            return item.exists !== undefined && item.exists;
        }

        function processImages(item, parent, contentFolder, targetFolder) {
            item.images.forEach(function (image) {
                var imageItem = {
                    name: image.fileName,
                    fileName: image.fileName,
                    parentPath: parent,
                    filePath: imageService.buildImagePath(image, contentFolder),
                    type: 'image',
                    hasChildren: false,
                    exists: image.exists,
                    size : image.size,
                    dimension: image.dimension,
                    isValid : image.isValid
              }
                image.filePath = imageItem.filePath;
                image.fullPath = imageService.createUnCachedImageFileName(image.filePath);
                imageItem.fullPath = image.fullPath;
                image.parentPath = imageItem.parentPath;

                image.name = image.filename;

                imagesToBuild.push({
                    filePath: image.filePath,
                    targetFolder: targetFolder
                });
                item.nodes.push(imageItem);
            });
        }

        function buildData(items, parentPath,contentFolder, targetFolder) {
            items.forEach(function (item) {
                item.nodes = [];
                item.parentPath = parentPath;
                var parent = parentPath + '/' + item.name;
                if (item.images === undefined) {
                    item.images = [];
                }

                item.hasChildren = item.images.length > 0;

                if (item.hasChildren) {
                    processImages(item, parent, contentFolder,targetFolder);
                }

                if (item.groups.length > 0) {
                    item.hasChildren = true;
                    buildData(item.groups, parent, contentFolder, targetFolder).forEach(
                         function (node) {
                             item.nodes.push(node);
                         });
                }
            });
            return items;
        }


        function anyImagesInvalid(images) {
            for (var i = 0; i < images.length; i++) {
                if (!images[i].isValid) {
                    return true;
                }
            }
            return false;
        }

        function buildImageInfo(items) {
            var build = { foundCount: 0, count: 0 , isValid: true};

            items.forEach(function (item) {
                if (hasNodes(item)) {
                    var counts = buildImageInfo(item.nodes);

                    item.count = counts.count;
                    item.foundCount = counts.foundCount;
                    item.isValid = counts.isValid;
                    build.count += item.count;
                    build.foundCount += counts.foundCount;
                    if (!counts.isValid) {
                        build.isValid = false;
                    }
                  
                }

                if (hasExistsProperty(item))
                    build.foundCount++;

                if (item.images != undefined && angular.isArray(item.images)) {
                    if (anyImagesInvalid(item.images)) {
                        build.isValid = false;
                    }
                } else {
                    if (!item.isValid) {
                        build.isValid = false;
                    }
                }

                if (item.filePath !== undefined)
                    build.count++;
            });

            return build;
        }

 
        function build(data) {
            var nodeItems = [],
                tabList = [];

            imagesToBuild = [];

            data.imageTypeSet.forEach(function (imageType) {
                nodeItems.push({
                    contentPath : imageType.contentPath,
                    name: imageType.name,
                    nodes: buildData(imageType.imageGroups, imageType.name, imageType.contentPath, imageType.targetFolder),
                    hasChildren: true,
                    images: []
                });

                tabList.push(imageType);
            });

            return {
                nodeItems: nodeItems,
                tabList: tabList,
                selectedTab: tabList[0],
                imagesToBuild: imagesToBuild
            }
        }

        return {
            build: build,
            buildImageInfo: buildImageInfo
        }
    }
})();