﻿(function () {
    'use strict';

    angular.module('bobApp')
           .service('helperService', helperService);

    function helperService() {

        this.urlDecodeArray = function (arrayToUse, propertiesToDecode) {
            var arrayChange =[];

            if (angular.isArray(arrayToUse)) {
                var isArray = angular.isArray(propertiesToDecode);

                arrayToUse.forEach(function (element) {
                    if (!isArray)
                        element[propertiesToDecode] = decodeURIComponent(element[propertiesToDecode]);
                    else {
                        propertiesToDecode.forEach(function(property) {
                            element[property] = decodeURIComponent(element[property]);
                        });
                    }

                    arrayChange.push(element);
                });
                return arrayChange;
            }

            console.log("no array found for helper.urlDecodeArray");
            return arrayToUse;
        }

        this.concatUrl = function (baseUrl, subParts) {

            var url = baseUrl.replace(/\/$/, '').replace(/\\$/, '');
            if (angular.isArray(subParts)) {
                subParts.forEach(function (element) {
                  url = url + '/' + removeSlashIfAtStartOrEndOfString(element);
                });
            } else {
                url = url + '/' + removeSlashIfAtStartOrEndOfString(subParts);
            }
            return url;
            }


        function removeSlashIfAtStartOrEndOfString(element) {
            if (charIsASlash(element[0])) {
                element = element.substr(1);
            }
            var len = element.length - 1;
            if (charIsASlash(element[len])) {
                element = element.substr(0, len);
            }

            return element;
        }

        function charIsASlash(char) {
            return char === '\\' || char === '/';
        }
    }
})();