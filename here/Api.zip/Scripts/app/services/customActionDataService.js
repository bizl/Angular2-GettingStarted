﻿(function () {
    'use strict';

    angular.module('bobApp')
           .service('customActionDataService', customActionDataService);

    customActionDataService.$inject = ['$http', 'configuration'];

    function customActionDataService($http, configuration) {
        this.processAction = function (selectedVehicle, contentPath, actionName, formatType, imageType) {
                var postModel = {
                    market: selectedVehicle.market.code,
                    model: selectedVehicle.model.code,
                    year: selectedVehicle.year.code,
                    contentPath : contentPath,
                    customAction: actionName,
                    formatType: formatType,
                    imageType: imageType
                };

                return $http.post(configuration.customActionUrl, JSON.stringify(postModel), configuration.headers);
            }

            this.processFiles = function (selectedVehicle, contentPath, actionName, files, formatType) {
             var postModel = {
                 market: selectedVehicle.market.code,
                 model: selectedVehicle.model.code,
                 year: selectedVehicle.year.code,
                 contentPath: contentPath,
                 customAction: actionName,
                 fileNames: files,
                 formatType: formatType
             };

                return $http.post(configuration.customFilesUrl,
                    JSON.stringify(postModel),
                    configuration.headers,
                    formatType);
            }
    }
})();