﻿(function () {
    'use strict';

    angular.module('bobApp')
           .service('unmatchedDataService', unmatchedDataService);

    unmatchedDataService.$inject = ['$http', 'configuration'];

    function unmatchedDataService($http, configuration) {


        this.getUnmatched = function (files, market, model, year, formatType) {
            var postModel = {
                files : files,
                market: market.code,
                model: model.code,
                year: year.code,
                formatType:formatType
            };

            return $http.post(configuration.baseUnMatchedUrl, JSON.stringify(postModel), configuration.headers);
        }
    }
})();