﻿(function () {
    'use strict';

    angular.module('bobApp')
           .service('imageInfoService', imageInfoService);

    imageInfoService.$inject = ['$http', 'configuration'];

    function imageInfoService($http, configuration) {

        this.getImageInfo = function (path) {
            return $http.get(configuration.baseImageInfo + '?path=' + encodeURIComponent(path), configuration.headers);
        }
    }
})();