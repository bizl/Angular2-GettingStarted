﻿(function () {
    'use strict';

    angular.module('bobApp')
           .service('zipDataService', zipDataService);

    zipDataService.$inject = ['$http', 'configuration',  'helperService'];

    function zipDataService($http, configuration, helperService) {
        this.buildZip = function (imageFiles, market, model, year, formatType) {
            var postModel = {
                files: helperService.urlDecodeArray(imageFiles,['filePath','targetFolder']),
                market: market.code,
                model: model.code,
                year: year.code,
                formatType: formatType
            };

            return $http.post(configuration.baseZipUrl, JSON.stringify(postModel), configuration.headers);
        }
    }
})();


