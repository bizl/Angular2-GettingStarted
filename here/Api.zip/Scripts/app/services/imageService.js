﻿(function () {
    'use strict';

    angular.module('bobApp')
           .service('imageService', imageService);

    imageService.$inject = ['$q', 'configuration', 'helperService'];

    function imageService($q, configuration, helper) {
        this.doesImageExist = function (item) {
            var src = item.filePath,
                deferred = $q.defer(),
                image = new Image();

            image.onerror = function () {
                item.exists = false;
                deferred.resolve(false);
            };
            image.onload = function () {
                item.exists = true;
                deferred.resolve(true);
            };
            image.src = src + '?=' + Math.random();

            return deferred.promise;
        }

        this.buildImagePath = function (image, path) {
            return helper.concatUrl(configuration.baseImageUrl , [path , encodeURIComponent(image.fileName)]);
        };

        this.createUnCachedImageFileName = function (fileName) {
            return fileName + '?' + Math.random();
        }
    }
})();