﻿'use strict';

angular.module('bobApp')
       .service('configService', configService);

configService.$inject = ['$http', 'configuration'];

function configService($http, configuration) {
     this.getConfiguration = function () {
        return $http.get(configuration.configurationUrl);
    }
}