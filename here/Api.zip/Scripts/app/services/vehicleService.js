﻿(function () {
    'use strict';

    angular.module('bobApp')
           .service('vehicleService', vehicleService);
    
    function vehicleService() {
        this.model = {};
        this.market = {};
        this.year = {};
    }
   
})();
