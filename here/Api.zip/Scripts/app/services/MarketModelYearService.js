﻿(function () {
    'use strict';

    angular.module('bobApp')
           .service('marketModelYearDataService', marketModelYearDataService);

    marketModelYearDataService.$inject = ['$http', 'configuration'];

    function marketModelYearDataService($http, configuration) {

        this.gettingMarket = function () {
            return $http.get(configuration.baseApiUrl + configuration.marketUrl, configuration.headers);
        },
        this.gettingSelf = function (selfUrl) {
            return $http.get(configuration.baseApiUrl + selfUrl, configuration.headers);
        }

        this.gettingGroups = function (market, model, year, formatType) {
            return $http.get(configuration.baseGroupImagesUrl  +
                            '/market/' + market +
                            '/model/' + model +
                            '/year/' + year +
                            '/formatType' + formatType , configuration.headers);
        }
    }
})();