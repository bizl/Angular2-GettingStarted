﻿(function () {
    "use strict";

    angular
        .module("bobApp")
        .controller("imageViewController", imageViewController);

    imageViewController.$inject = ["$stateParams"];

    function imageViewController(stateParams) {
        var vm = this;

        vm.toggleSize = function (image) {
            image.fullScreen = !image.fullScreen;
        }

        vm.getImageSource = function () {
            return stateParams;
        }
    }
})();