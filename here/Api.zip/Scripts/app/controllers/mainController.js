﻿(function () {
    "use strict";

    angular.module("bobApp")
        .controller("mainController", mainController);

    mainController.$inject = [
        "$state",
        "$q",
        "$rootScope",
        "configService",
        "vehicleService",
        "marketModelYearDataService",
        "imageService",
        "imageBuilderService",
        "directoryBuilderService",
        "zipDataService",
        "unmatchedDataService",
        "customActionDataService",
        "toastr",
        "configuration",
        "$timeout"
    ];

    function mainController($state,
        $q,
        $rootScope,
        configService,
        vehicleService,
        marketModelYearDataService,
        imageService,
        imageBuilderService,
        directoryBuilderService,
        zipDataService,
        unmatchedDataService,
        customActionDataService,
        toaster,
        configuration,
        $timeout) {

        var vm = this;

        vm.changeMarket = changeMarket;
        vm.showMenu = false;
        vm.showZip = false;
        vm.changeModel = changeModel;
        vm.buildZip = buildZip;
        vm.vehicle = vehicleService;
        vm.vehicleHasChanged = vehicleHasChanged;
        vm.isLink = isLink;
        vm.tabClicked = tabClicked;
        vm.refreshView = refreshView;
        vm.missingFiles = missingFiles;
        vm.actionClick = actionClick;
        vm.showTree = false;
        vm.changeFormatSelection = changeFormatSelection;
        vm.toggleMenu = toggleMenu;

        configService.getConfiguration().then(function (configData) {
            angular.extend(configuration, configData.data);
            configuration.baseApiUrl = configuration.baseUrl + configData.data.formatTypes[0].self;
            configuration.baseImageUrl = configuration.baseImage + configData.data.formatTypes[0].self;

            activate();
        });

        vm.gridSetup = {
            height: 400,
            columns: [
                {
                    title: "Filename",
                    field: "source.displayName"
                },
                {
                    title: "Source",
                    columns: [
                        { title: "Size (kb)", field: "source.size", template: "#= kendo.parseInt(source.size / 1024) #" },
                        {
                            title: "Last Modified",
                            field: "source.modifiedDateTime",
                            type: "datetime",
                            template: "#= kendo.toString(kendo.parseDate(source.modifiedDateTime), 'dd MMM yyyy hh:mm') #"
                        }]
                }, {
                    title: "Destination",
                    columns: [
                        { title: "Size (kb)", field: "destination.size", template: "#= kendo.parseInt(destination.size / 1024) #" },
                        {
                            title: "Last Modified",
                            field: "destination.modifiedDateTime",
                            template: "#= kendo.toString(kendo.parseDate(destination.modifiedDateTime), 'dd MMM yyyy hh:mm') #"
                        }]
                }, {
                    field: "overwrite",
                    title: "<input type='checkbox'  ng-click='vm.toggleSelectAll($event)' ng-model='vm.overwrite' title='Select all'  />Overwrite?</input>",
                    template: "<input type='checkbox' name='overwrite' class='checkbox' ng-model='dataItem.selected'/>"
                }
            ]
        };

        function showSpinner() {
            kendo.ui.progress($("body"), true);
        }

        function hideSpinner() {
            kendo.ui.progress($("body"), false);
        }

        function toggleMenu() {
            vm.showMenu = !vm.showMenu;
        }

        function updateUrl(options) {
            var stateParams = {};

            angular.forEach(options, function (option, key) {
                stateParams[key] = option || option === null ? option : $state.params[key];
            });

            $state.go(".", stateParams, {notify: false});
        }

        function resetVehicleProperty(property) {
            var collectionName = property + "s";

            delete vm.vehicle[property];
            vm.showZip = false;
            vm[collectionName] = {};
        }

        vm.toggleSelectAll = function (evt) {
            var grid = $(evt.target).closest("[kendo-grid]").data("kendoGrid");
            var items = grid.dataSource.data();
            items.forEach(function (item) {
                item.selected = evt.target.checked;
            });
        }

        function setUpToastr() {
            toaster.options = {
                "closeButton": false,
                "debug": false,
                "newestOnTop": false,
                "progressBar": true,
                "positionClass": "toast-top-right",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
            };
        }

        function actionClick(actionName) {
            showSpinner();

            var selectedTab = vm.selectedTab;
            var selectedItem = getSelectedItem(vm.selectedTab);

            customActionDataService.processAction(
                vehicleService.selectedVehicle,
                    selectedItem.contentPath,
                    actionName,
                    vm.selectedFormatType.code,
                    vm.selectedTab.name)
                .then(function (result) {
                    hideSpinner();
                    updateTabData(result.data);
                    tabClicked(selectedTab);
                    toaster.success(result.data.FilesCopied  + "colourchips copied");
                    if (checkIfFilesAlreadyExist(result.data))
                        showFilesDialog(result.data.filesAlreadyExist);

                }, function () {
                    hideSpinner();
                    toaster.error("Action failed");
                });
        }

        function checkIfFilesAlreadyExist(data) {
            return angular.isDefined(data.filesAlreadyExist) &&
                angular.isArray(data.filesAlreadyExist);
        };

        function isLink(dataItem) {
            return (!angular.isUndefined(dataItem.type));
        };

        function tabClicked(tab) {
            $state.go("imageView2");
            setImageTreeData(tab);
        };

        function refreshView() {
            $rootScope.$broadcast("vehicleChange");
        };

        function createImageTreeDataSource(data) {
            return new kendo.data.HierarchicalDataSource({
                data: data,
                schema: {
                    model: {
                        children: "nodes",
                        hasChildren: "hasChildren"
                    }
                }
            });
        }

        function updateTabData(data) {
            var tab = vm.selectedTab.name;
            for (var i = 0; i < vm.dataItems.length; i++) {
                var item = vm.dataItems[i];
                if (item.name === tab) {
                    var builderData = imageBuilderService.build({ imageTypeSet: [data.imageTypeSet] });
                    vm.dataItems[i] = builderData.nodeItems[0];
                    imageBuilderService.buildImageInfo(builderData.nodeItems);
                    break;
                }
            };
        }

        function setImageTreeData(tab) {
            for (var i = 0; i < vm.dataItems.length; i++) {
                var item = vm.dataItems[i];
                if (item.name === tab.name) {
                    vm.selectedTab = tab;
                    vm.treeData = createImageTreeDataSource(item.nodes);
                    break;
                }
            };
        }

        function getSelectedItem(tab) {
            for (var i = 0; i < vm.dataItems.length; i++) {
                var item = vm.dataItems[i];
                if (item.name === tab.name) {
                    return item;
                }
            };
        }

        function changeFormatSelection() {
            updateUrl({
                domain: vm.selectedFormatType.code,
                market: null,
                model: null,
                year: null
            });

            resetVehicleProperty("market");
            resetVehicleProperty("year");
            resetVehicleProperty("model");

            configuration.baseApiUrl = configuration.baseUrl + vm.selectedFormatType.self;
            configuration.baseImageUrl = configuration.baseImage + vm.selectedFormatType.self;

            showSpinner();
            populatingDropdowns().then(function () {
                hideSpinner();
            });
        }

        function showFilesDialog(files) {
            vm.files = new kendo.data.DataSource({
                data: files
            });

            vm.fileDialog.center().open();
        }

        vm.copyFiles = function () {
            var selectedItem = getSelectedItem(vm.selectedTab);

            var selected = vm.files.data().filter(function (value) {
                return value.selected;
            }).map(function (value) {
                return value.destination.name;
            });

            if (selected.length > 0) {
                showSpinner();

                customActionDataService.processFiles(vehicleService.selectedVehicle,
                    selectedItem.contentPath,
                    vm.selectedTab.customActions[0].name,
                    selected,
                    vm.selectedFormatType.code).
                then(function (result) {
                    hideSpinner();
                    updateTabData(result.data);
                    tabClicked(vm.selectedTab);
                    toaster.success("Action processed");
                }, function () {
                    hideSpinner();
                    toaster.error("Overwrite files failed");
                });
            }

            vm.fileDialog.close();
        }

        function changeMarket() {
            vm.showZip = false;
            vm.models = [];

            if (vm.vehicle.market.self.length > 0) {
                showSpinner();
                updateUrl({market: vm.vehicle.market.code});
                marketModelYearDataService.gettingSelf(vm.vehicle.market.self)
                    .then(function (modelData) {
                        hideSpinner();
                        vm.models = modelData.data;
                        resetVehicleProperty("year");
                    });
            }
        }

        function changeModel() {
            vm.showZip = false;
            vm.years = [];

            if (vm.vehicle.model.self.length > 0) {
                showSpinner();
                updateUrl({ model: vm.vehicle.model.code });
                marketModelYearDataService.gettingSelf(vm.vehicle.model.self)
                    .then(function (yearData) {
                        hideSpinner();
                        delete vm.vehicle.year;
                        vm.years = yearData.data;
                    });
            }
        }

        function buildZip() {
            kendo.ui.progress($("body"), true);
            toaster.info("Building a zip might take a while, please be patient");
            zipDataService.buildZip(vehicleService.imagesToBuild,
                    vehicleService.selectedVehicle.market,
                    vehicleService.selectedVehicle.model,
                    vehicleService.selectedVehicle.year,
                    vm.selectedFormatType.code
                )
                .then(function (result) {
                    toaster.success(result.data);
                },
                    function () {
                        toaster.error("Zip file creation failed");
                    })
                .finally(function () {
                    kendo.ui.progress($("body"), false);
                });
        }

        function mapFiles(item) {
            return item.filePath;
        }

        function missingFiles() {
            kendo.ui.progress($("body"), true);
            toaster.info("Finding missing files might take a while, please be patient");
            unmatchedDataService.getUnmatched(vehicleService.imagesToBuild.map(mapFiles),
                    vehicleService.selectedVehicle.market,
                    vehicleService.selectedVehicle.model,
                    vehicleService.selectedVehicle.year,
                    vm.selectedFormatType.code)
                .then(function (result) {
                    vm.missingData = buildMissingData(result.data);
                },
                function () {
                    toaster.error("Error access missing files");
                })
                .finally(function () {
                    kendo.ui.progress($("body"), false);
                });
        }

        function buildMissingData(dataToMap) {
            var data = directoryBuilderService.build(dataToMap);
            vm.showUnmatched = true;

            return new kendo.data.HierarchicalDataSource({
                data: data.items,
                schema: {
                    model: {
                        children: "items"
                    }
                }
            });
        }

        function getOptionByKey(options, key) {
            var selectedOption = null,
                upperCaseKey = key.toUpperCase(),
                optionsIndex = options.length;

            while (optionsIndex--) {
                if (options[optionsIndex].code === upperCaseKey) {
                    selectedOption = options[optionsIndex];
                    break;
                }
            }

            return selectedOption;
        }       

        function populatingDropdowns() {
           return $q(function (resolve, reject) {
                marketModelYearDataService.gettingMarket().then(function (marketData) {
                    vm.markets = marketData.data;
                    if ($state.params.market) {
                        vm.vehicle.market = getOptionByKey(vm.markets, $state.params.market);
                        marketModelYearDataService.gettingSelf(vm.vehicle.market.self).then(function (modelData) {
                            vm.models = modelData.data;
                            if ($state.params.model) {
                                vm.vehicle.model = getOptionByKey(vm.models, $state.params.model);
                                marketModelYearDataService.gettingSelf(vm.vehicle.model.self).then(function (yearData) {
                                    vm.years = yearData.data;
                                    if ($state.params.year) {
                                        vm.vehicle.year = getOptionByKey(vm.years, $state.params.year);
                                    }
                                });
                                resolve();
                            } else {
                                resolve();
                            }
                        });
                    } else {
                        resolve();
                    }
                }, function () {
                    reject();
                });
            });
        }

        function activate() {
            vm.formatTypes = configuration.formatTypes;
            vm.selectedFormatType = $state.params.domain ? getOptionByKey(vm.formatTypes, $state.params.domain) : vm.formatTypes[0];

            if (!$state.params.domain) {
                updateUrl({ domain: vm.selectedFormatType.code });
            }
            
            configuration.baseApiUrl = configuration.baseUrl + vm.selectedFormatType.self;
            configuration.baseImageUrl = configuration.baseImage + vm.selectedFormatType.self;

            showSpinner();

            populatingDropdowns().then(function () {
                hideSpinner();
            });

            setUpToastr();
            vm.showUnmatched = false;
            $rootScope.$on("vehicleChange", vehicleChange);

            if ($state.params.year) {
                vm.isSelected = true;
                vm.showZip = true;
                vehicleService.selectedVehicle = {
                    market: {code: $state.params.market},
                    model: {code: $state.params.model},
                    year: {code: $state.params.year}
                };

                vehicleChange();
            }
        }

        function buildImageData(result) {
            var builderData = imageBuilderService.build(result.data);
            vm.selectedTab = builderData.tabList[0];
            vm.tabList = builderData.tabList;
            vm.dataItems = builderData.nodeItems;
            vehicleService.imagesToBuild = builderData.imagesToBuild;

            imageBuilderService.buildImageInfo(builderData.nodeItems);
            setImageTreeData(vm.selectedTab);
            vm.showTree = true;

            hideSpinner();
        }

        function vehicleHasChanged() {
            if (vm.vehicle.year.self.length > 0) {
                vm.isSelected = true;
                showSpinner();
                updateUrl({ year: vm.vehicle.year.code });
                vm.showZip = true;
                vehicleService.selectedVehicle = {
                    market: vm.vehicle.market,
                    model: vm.vehicle.model,
                    year: vm.vehicle.year
                };
                $rootScope.$broadcast("vehicleChange");
            }
        }

        function vehicleChange() {
            showSpinner();
            toaster.info("Collecting build information, this might take a while, please be patient");
            vm.treeData = {};

            marketModelYearDataService.gettingGroups(vehicleService.selectedVehicle.market.code,
                    vehicleService.selectedVehicle.model.code,
                    vehicleService.selectedVehicle.year.code,
                    vm.selectedFormatType.self)
                .then(function (result) {
                    buildImageData(result);
                }, function () {
                    hideSpinner();
                    toaster.error("An error has occurred on populating vehicle data");
                });
        }
    };
})();