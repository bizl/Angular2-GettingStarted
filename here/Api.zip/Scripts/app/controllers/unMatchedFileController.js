﻿(function () {
    "use strict";

    angular
        .module("bobApp")
        .controller("unMatchedFileController", unMatchedFileController);

    unMatchedFileController.$inject = ["$stateParams"];

    function unMatchedFileController(stateParams) {
        var vm = this;
        vm.toggle = toggle;
        vm.fullScreen = false;
        vm.filePath = stateParams.filePath;

        function toggle() {
            vm.fullScreen = !vm.fullScreen;
        }
    }
})();