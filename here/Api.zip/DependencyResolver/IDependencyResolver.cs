namespace Bob.UI.DependencyResolver
{
    public interface IDependencyResolver
    {
        T Resolve<T>(string name);
    }
}
