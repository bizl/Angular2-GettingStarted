using Microsoft.Practices.Unity;

namespace Bob.UI.DependencyResolver
{
    public class DependencyResolver : IDependencyResolver
    {
        private readonly IUnityContainer _resolver;

        public DependencyResolver(IUnityContainer unity)
        {
            _resolver = unity;
        }

        public T Resolve<T>(string name)
        {
            return _resolver.Resolve<T>(name);
        }
    }
}
