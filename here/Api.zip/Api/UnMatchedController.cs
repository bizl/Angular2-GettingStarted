﻿using System.Collections.Generic;
using System.Web.Http;
using Bob.Domain.Interfaces;
using Bob.Domain.Models;
using Bob.UI.Models;

namespace Bob.UI.Api
{
    public class UnMatchedController : ApiController
    {
        private readonly IPackageValidation _packageValidation;

        public UnMatchedController(IPackageValidation packageValidation)
        {
            _packageValidation = packageValidation;
        }

        [HttpPost]
        public IHttpActionResult Post(UnMatchedRequestModel model)
        {
            DomainMarketModelYearModel dmmy = ToDomainMarketModelYearModel(model);
            IEnumerable<string> result = _packageValidation.IdentifyMissingAndUnexpectedImages(dmmy);
            return Ok(result);
        }

        private static DomainMarketModelYearModel ToDomainMarketModelYearModel(UnMatchedRequestModel model)
        {
            return new DomainMarketModelYearModel
            {
                Domain = model.FormatType,
                Market = model.Market,
                Model = model.Model,
                Year = model.Year
            };
        }
    }
}
