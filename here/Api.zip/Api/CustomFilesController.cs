﻿using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using Bob.Domain.Interfaces;
using Bob.Domain.Models;
using Bob.Services.DataApi.Domain.Interfaces;
using Bob.Services.DataApi.Domain.Models;
using Bob.UI.DependencyResolver;
using Bob.UI.Models;

namespace Bob.UI.Api
{
    public class CustomFilesController : ApiController
    {
        private readonly IOverWriteSelectedCustomFiles _customFiles;
        private readonly IDependencyResolver _dependencyResolver;
        private readonly IImageRepository _imageRepository;
        private readonly IImageService _imageService;

        public CustomFilesController(
            IImageRepository imageRepository,
            IImageService imageService,
            IOverWriteSelectedCustomFiles overWriteSelectedCustomFiles,
            IDependencyResolver dependencyResolver)
        {
            _customFiles = overWriteSelectedCustomFiles;
            _imageRepository = imageRepository;
            _imageService = imageService;
            _dependencyResolver = dependencyResolver;
        }

        public async Task<HttpResponseMessage> Post([FromBody] PostCustomActionFilesModel model)
        {
            var fileCopySpecification = _dependencyResolver.Resolve<IFileCopySpecification>(model.CustomAction);

            CustomActionImages images =
                await _imageRepository.GetCustomActionImages(model.CustomAction, model.FormatType, model.Market,
                    model.Model, model.Year);

            _customFiles.OverwriteExistingFiles(
                model.FormatType,
                model.FileNames,
                images,
                fileCopySpecification);

            ImageType imageTypeData =
                await _imageService.Retrieve(ToDomainMarketModelYearModel(model), model.CustomAction);
            return Request.CreateResponse(HttpStatusCode.Created, new {ImageTypeSet = imageTypeData});
        }

        private static DomainMarketModelYearModel ToDomainMarketModelYearModel(PostCustomActionFilesModel model)
        {
            return new DomainMarketModelYearModel
            {
                Domain = model.FormatType,
                Market = model.Market,
                Model = model.Model,
                Year = model.Year
            };
        }
    }
}
