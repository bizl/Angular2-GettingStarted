﻿using System.Threading.Tasks;
using System.Web.Http;
using Bob.Domain.Interfaces;
using Bob.UI.Models;

namespace Bob.UI.Api
{
    public class ConfigurationController : ApiController
    {
        private readonly IConfigurationTypeService _configurationTypeService;
        private readonly IConfigurationService _configurationService;

        public ConfigurationController(IConfigurationTypeService configurationTypeService,
            IConfigurationService configurationService)
        {
            _configurationTypeService = configurationTypeService;
            _configurationService = configurationService;
        }

        public async Task<ConfigurationModel> Get()
        {
            return new ConfigurationModel
            {
                FormatTypes = await _configurationTypeService.GetConfigurationFormatTypes(),
                BaseUrl = _configurationService.ApiAddress
            };
        }
    }
}