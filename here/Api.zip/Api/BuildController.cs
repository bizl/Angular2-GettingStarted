﻿using System;
using System.Threading.Tasks;
using System.Web.Http;
using Bob.Domain.Interfaces;
using Bob.Domain.Models;
using Bob.UI.Models;

namespace Bob.UI.Api
{
    public class BuildController : ApiController
    {
        private readonly IPackageService _packageService;

        public BuildController(IPackageService packageService)
        {
            _packageService = packageService;
        }

        public async Task<IHttpActionResult> Post([FromBody] ZipFileRequestModel zipFileRequestModel)
        {
            try
            {
                PackageSpecificationModel packageModel = ToPackageModel(zipFileRequestModel);
                string zipFilePath = await _packageService.BuildPackage(packageModel);
                return Ok($"{zipFilePath} was created");
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception(ex.Message));
            }
        }

        private static PackageSpecificationModel ToPackageModel(ZipFileRequestModel zipFileRequestModel)
        {
            return new PackageSpecificationModel
            {
                Files = zipFileRequestModel.Files,
                Domain = zipFileRequestModel.FormatType,
                Market = zipFileRequestModel.Market,
                Model = zipFileRequestModel.Model,
                Year = zipFileRequestModel.Year
            };
        }
    }
}
