﻿using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using Bob.Domain.Interfaces;
using Bob.Domain.Models;
using Bob.Services.CustomActions.Interfaces;
using Bob.Services.CustomActions.Models;
using Bob.UI.DependencyResolver;
using Bob.UI.Models;

namespace Bob.UI.Api
{
    public class CustomActionController : ApiController
    {
        private readonly IDependencyResolver _dependencyResolver;

        public CustomActionController(IDependencyResolver dependencyResolver)
        {
            _dependencyResolver = dependencyResolver;
        }

        public async Task<HttpResponseMessage> Post([FromBody] PostCustomModel postCustomModel)
        {
            try
            {
                CustomActionModel customActionModel = ToCustomActionModel(postCustomModel);
                ICustomActionService customAction =
                    _dependencyResolver.Resolve<ICustomActionService>(customActionModel.CustomAction);
                return Request.CreateResponse(HttpStatusCode.Created, await customAction.Process(customActionModel));
            }
            catch (Exception e)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest,
                    $"CustomActionController.Post exception, {e.Message}.");
            }
        }

        private static CustomActionModel ToCustomActionModel(PostCustomModel postModel)
        {
            return new CustomActionModel
            {
                ContentPath = postModel.ContentPath,
                CustomAction = postModel.CustomAction,
                Domain = postModel.FormatType,
                Market = postModel.Market,
                Model = postModel.Model,
                Year = postModel.Year,
                ImageType = postModel.ImageType
            };
        }
    }
}
