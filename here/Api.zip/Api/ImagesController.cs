﻿using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using Bob.Domain.Interfaces;
using Bob.Domain.Models;
using Bob.Services.DataApi.Domain.Models;

namespace Bob.UI.Api
{
    public class ImagesController : ApiController
    {
        private readonly IImageService _imageService;

        public ImagesController(IImageService imageService)
        {
            _imageService = imageService;
        }

        public async Task<HttpResponseMessage> Get(string market, string model, string year, string formatType)
        {
            var formatTypeMarketModelYearModel = new DomainMarketModelYearModel
            {
                Market = market,
                Model = model,
                Year = year,
                Domain = formatType
            };

            ImageTypes result = await _imageService.Retrieve(formatTypeMarketModelYearModel);

            return Request.CreateResponse(new {result.ImageTypeSet});
        }
    }
}
