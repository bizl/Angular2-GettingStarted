/// <binding AfterBuild='scripts, css' Clean='clean' />
var gulp = require("gulp"),
    concat = require("gulp-concat"),
    uglify = require("gulp-uglify"),
    del = require("del"),
    cssshrink = require("gulp-cssshrink"),
    sourcemaps = require("gulp-sourcemaps");

var config = {
    //Include all js files but exclude any min.js files
    src: ["scripts/app/**/*.js", "!app/**/*.min.js"]
}

//delete the output file(s)
gulp.task("clean", function () {
    //del is an async function and not a gulp plugin (just standard nodejs)
    //It returns a promise, so make sure you return that from this task function
    //  so gulp knows when the delete is complete
    return del(["app/*"]);

});

// Combine and minify all files from the app folder
// This tasks depends on the clean task which means gulp will ensure that the 
// Clean task is completed before running the scripts task.
gulp.task("scripts", ["clean"], function () {

    return gulp.src(config.src)
      .pipe(sourcemaps.init())
      .pipe(uglify({mangle: false}))
      .pipe(concat("all.min.js"))
      .pipe(sourcemaps.write())
      .pipe(gulp.dest("app/"));
});


//Set a default tasks
gulp.task("default", ["scripts"], function () { });

gulp.task("watch", function () {
    return gulp.watch(config.src, ["scripts"]);
});