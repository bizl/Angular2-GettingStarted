using System.Configuration;
using System.Web;
using System.Web.Http;
using Bob.Core.Factory;
using Bob.Core.Helper;
using Bob.Core.Services;
using Bob.Domain.Interfaces;
using Bob.Services.CustomActions;
using Bob.Services.DataApi;
using Bob.Services.DataApi.Domain.Interfaces;
using Bob.Services.FilenameResolvers;
using Bob.UI.DependencyResolver;
using Burrows.Image;
using Burrows.SubstitutionService.Domain.Interfaces;
using Burrows.SubstitutionService.FeatureSubstitution;
using Microsoft.Practices.Unity;
using Unity.WebApi;
using Bob.Services.CustomActions.Interfaces;

namespace Bob.UI
{
    public static class UnityConfig
    {
        public static void RegisterComponents()
        {
            var container = new UnityContainer();

            container.RegisterTypes(
                AllClasses.FromLoadedAssemblies(),
                WithMappings.FromMatchingInterface,
                WithName.Default);

            container.RegisterType<IFileSystem, FileSystem>();
            container.RegisterType<IVirtualFileSystem, IisFileSystem>();
            container.RegisterType<IConfigurationService, ConfigurationService>();
            container.RegisterType<ILinkingRecordService, LinkingRecordService>();
            container.RegisterType<IPackageService, PackageService>();
            container.RegisterType<IZipService, ZipService>();
            container.RegisterType<IPackageValidation, PackageValidationService>();
            container.RegisterType<IImageRepository, ImageRepository>();
            container.RegisterType<IOverWriteSelectedCustomFiles, OverWriteSelectedCustomFiles>();
            container.RegisterType<IImageHelper, ImageHelper>();

            container.RegisterType<HttpServerUtilityBase, HttpServerUtilityWrapper>(
                new InjectionConstructor(HttpContext.Current.Server));

            string apiAddress = ConfigurationManager.AppSettings["ApiAddress"];
            container.RegisterType<IRestfulGetter, RestfulGetterService>(new InjectionConstructor(apiAddress));

            container.RegisterType<IHttpClientFactory, HttpClientFactory>();
            container.RegisterType<IImageRepository, ImageRepository>();
            container.RegisterType<IImageInfoService, ImageInfoService>();
            container.RegisterType<ISetFileProperties, SetFileProperties>();
            container.RegisterType<IValidationImageService, ValidationImageService>();
            container.RegisterType<IVirtualFileSystem, IisFileSystem>();
            container.RegisterType<IImageService, ImageService>();

            container.RegisterType<IFeatureSubstitutionService, FeatureSubstitutionService>();

            container.RegisterType<IFilenameResolver, OptionCarouselFilenameResolver>("Option Carousel");
            container.RegisterType<IFilenameResolver, TrimFilenameResolver>("Trim Carousel");
            container.RegisterType<IFilenameResolver, ColourFilenameResolver>("Colourchip");
            container.RegisterType<IFilenameResolver, LayerOptionFilenameResolver>("Layered Options Carousel");

            container.RegisterType<IFileCopySpecification, TrimCarouselFileCopySpecification>("Trim Carousel",
                new InjectionFactory(
                    c =>
                        new TrimCarouselFileCopySpecification(
                            c.Resolve<IConfigurationService>(),
                            c.Resolve<IFilenameResolver>("Trim Carousel"))));

            container.RegisterType<IFileCopySpecification, ColourChipFileCopySpecification>("Colourchip",
                new InjectionFactory(
                    c =>
                        new ColourChipFileCopySpecification(
                            c.Resolve<IConfigurationService>(),
                            c.Resolve<IFilenameResolver>("Colourchip"))));

            container.RegisterType<IFileCopySpecification, OptionCarouselFileCopySpecification>("Option Carousel",
                new InjectionFactory(
                    c =>
                        new OptionCarouselFileCopySpecification(
                            c.Resolve<IConfigurationService>(),
                            c.Resolve<IFileSystem>(),
                            c.Resolve<IFilenameResolver>("Option Carousel"))));

            container.RegisterType<IFileCopySpecification, LayeredOptionsFileCopySpecification>(
                "Layered Options Carousel",
                new InjectionFactory(
                    c =>
                        new LayeredOptionsFileCopySpecification(
                            c.Resolve<IConfigurationService>(),
                            c.Resolve<IFileSystem>(),
                            c.Resolve<IFilenameResolver>("Option Carousel"))));

            container.RegisterType<ICustomActionService, CustomActionService>("Trim Carousel",
                new InjectionFactory(
                    c =>
                        new CustomActionService(
                            c.Resolve<IFileSystem>(),
                            c.Resolve<IImageService>(),
                            c.Resolve<IFileCopySpecification>("Trim Carousel"),
                            c.Resolve<IImageRepository>())));

            container.RegisterType<ICustomActionService, CustomActionService>("Colourchip",
                new InjectionFactory(
                    c =>
                        new CustomActionService(
                            c.Resolve<IFileSystem>(),
                            c.Resolve<IImageService>(),
                            c.Resolve<IFileCopySpecification>("Colourchip"),
                            c.Resolve<IImageRepository>())));

            container.RegisterType<ICustomActionService, CustomActionService>("Option Carousel",
                new InjectionFactory(
                    c =>
                        new CustomActionService(
                            c.Resolve<IFileSystem>(),
                            c.Resolve<IImageService>(),
                            c.Resolve<IFileCopySpecification>("Option Carousel"),
                            c.Resolve<IImageRepository>())));

            container.RegisterType<ICustomActionService, CustomActionService>("Layered Option Carousel",
                new InjectionFactory(
                    c =>
                        new CustomActionService(
                            c.Resolve<IFileSystem>(),
                            c.Resolve<IImageService>(),
                            c.Resolve<IFileCopySpecification>("Layered Option Carousel"),
                            c.Resolve<IImageRepository>())));

            container.RegisterType<IDependencyResolver, DependencyResolver.DependencyResolver>(
                new InjectionConstructor(container));

            GlobalConfiguration.Configuration.DependencyResolver = new UnityDependencyResolver(container);
        }
    }
}
